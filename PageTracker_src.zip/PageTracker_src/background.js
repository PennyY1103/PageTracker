chrome.runtime.onInstalled.addListener(() => {
	console.log("Background script running");
});